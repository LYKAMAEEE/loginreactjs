import React from 'react'

const MatchUpPage = () => {
  return (
    <div>MatchUp</div>
  )
}

export default MatchUpPage